/**
 * JNDI�֘A
 */
package jp.terasoluna.fw.web.jndi;